<?php 
session_start();
if(!isset($_SESSION['logged'])){
    header('Location:login.php');
}
if (isset($_SESSION['id']) && isset($_SESSION['username'])) {

 ?>
<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script defer src="wordle.js"></script>
  <script defer src="../mode.js"></script>
  <script defer src="../node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>

  <link rel="stylesheet" href="../Styles/wordle.css" />
   <link rel="stylesheet" href="../Styles/root.css">
   <link rel="stylesheet" href="../Styles/gameNav.css">
  <script type="text/javascript">
    var userName = '<?php echo $_SESSION['username']; ?>';
  </script>
  <title>GAMMY</title>
</head>

<body>
  <div class="vertical_nav">
    <div class="logoName">
      <a href="" class="logo">
        <img src="../images/logo.png" />
        <span>GammY</span>
      </a>
    </div>
    <div class="gameName">
    <span>Wordle</span>
    </div>
    <div class="theme">
      <img src="../images/sun.png" />
      <img src="../images/moon.png" />
    </div>
  </div>
  <div class="inst">
    <div class="instruct">
         <img src="../images/instructwordle.png" alt="">
    </div>
    <button id="close">
      Start
    </button>
  </div>
 
  <section class="content">
    <div class="alert-container" data-alert-container></div>
    <div data-guess-grid class="guess-grid">
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
      <div class="tile"></div>
    </div>
    <div data-keyboard class="keyboard">
      <button class="key" data-key="Q">Q</button>
      <button class="key" data-key="W">W</button>
      <button class="key" data-key="E">E</button>
      <button class="key" data-key="R">R</button>
      <button class="key" data-key="T">T</button>
      <button class="key" data-key="Y">Y</button>
      <button class="key" data-key="U">U</button>
      <button class="key" data-key="I">I</button>
      <button class="key" data-key="O">O</button>
      <button class="key" data-key="P">P</button>
      <div class="space"></div>
      <button class="key" data-key="A">A</button>
      <button class="key" data-key="S">S</button>
      <button class="key" data-key="D">D</button>
      <button class="key" data-key="F">F</button>
      <button class="key" data-key="G">G</button>
      <button class="key" data-key="H">H</button>
      <button class="key" data-key="J">J</button>
      <button class="key" data-key="K">K</button>
      <button class="key" data-key="L">L</button>
      <div class="space"></div>
      <button data-enter class="key large">Enter</button>
      <button class="key" data-key="Z">Z</button>
      <button class="key" data-key="X">X</button>
      <button class="key" data-key="C">C</button>
      <button class="key" data-key="V">V</button>
      <button class="key" data-key="B">B</button>
      <button class="key" data-key="N">N</button>
      <button class="key" data-key="M">M</button>
      <button data-delete class="key large">
        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
          <path fill="var(--color-tone-1)"
            d="M22 3H7c-.69 0-1.23.35-1.59.88L0 12l5.41 8.11c.36.53.9.89 1.59.89h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H7.07L2.4 12l4.66-7H22v14zm-11.59-2L14 13.41 17.59 17 19 15.59 15.41 12 19 8.41 17.59 7 14 10.59 10.41 7 9 8.41 12.59 12 9 15.59z">
          </path>
        </svg>
      </button>
    </div>
  </section>

</body>

</html>
<?php 
}else{
     header("Location: SignIn.php");
     exit();
}
 ?>