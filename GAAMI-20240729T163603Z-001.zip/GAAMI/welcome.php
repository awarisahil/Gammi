<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Styles/welcome.css">
    <title>Document</title>
</head>
<body>
    <!-- <img src="./images/welcome.gif" alt="" srcset=""> -->
    <div class="welcome">
         <h1>WELCOME TO GAMMY</h1>
         <h3>Begin your journey with "GAAMY"</h3>
     </div>
     <div class="Btn">
      <a href="SignUp.php"><button>Sign Up</button></a>
      <a href="login.php"><button>Sign In</button></a>
     </div>
</body>
</html>